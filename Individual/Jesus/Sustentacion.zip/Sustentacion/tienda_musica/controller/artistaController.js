import {artistaModel} from "../model/artistaModel.js"

export const crearDatosArtista = async (peticion, respuesta) => {
    try {
        let data = peticion.body
        await artistaModel.create(data)
        let artista = await artistaModel.find()
        respuesta.status(200).render("index", {artista})
    } catch (error) {
    console.log(error);
    }
}

export const artistaPais = async (peticion, respuesta) => {
    try {
        let data = peticion.body
        await artistaModel.create(data)
        let artista = await artistaModel.find({
            "pais" : "Colombia"
        })
        respuesta.status(200).render("index", {artista})
    } catch (error) {
        console.log(error);
    }
}



