import {albumModel} from "../model/albumModel.js"


export const crearDatosAlbum = async (peticion, respuesta) => {
    try {
        let data = peticion.body
        await albumModel.create(data)
        let album = await albumModel.find()
        respuesta.status(200).render("index", {album})
    } catch (error) {
        console.log(error);
    }
}

export const buscarAlbum =  async(peticion,respuesta) => {

    try {
        let album = await albumModel.find()
        respuesta.status(200).render("index", { album })
    } catch (error) {
        console.log(error);
    }
}

export const actulizarAlbumEspecifico =  async(peticion,respuesta) => {

    try {
        let nombre = await albumModel.findAndUpdate({
            "nombre" : "El Dorado"
        },{
            $set:{ "año" :  "2018"}
        }      
        )
        respuesta.status(200).render("index", { nombre })
    } catch (error) {
        console.log(error);
    }
}

export const eliminarAlbum = async (peticion, respuesta) => {
    try {
        let album = await albumModel.findAndDelete({
            "nombre" :  "m Abbey Road"
        })
        respuesta.status(200).render("index", { album })
    } catch (error) {
        console.log(error);
    }
}





