import { Schema } from "mongoose";

const artistaSchema = new Schema({

    "nombre": String,
    "genero" : String,
    "pais" : String

});

export const artistaModel = new mongoose.model('Artista', artistaSchema)