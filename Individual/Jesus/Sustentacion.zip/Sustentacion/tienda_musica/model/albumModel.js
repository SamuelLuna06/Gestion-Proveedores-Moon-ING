import { Schema } from "mongoose";

const albumSchema = new Schema({

    "nombre": String,
    "autor" : String,
    "año" : String

});

export const albumModel = new mongoose.model('Album', albumSchema)