import { Router } from "express";
import {crearDatosArtista,artistaPais} from "../controller/artistaController.js"

const router = Router()

router.post('/artista', crearDatosArtista); 
router.get('/artista', artistaPais); 


export default router;