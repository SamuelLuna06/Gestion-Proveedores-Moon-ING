import { Router } from "express";
import {crearDatosAlbum,buscarAlbum,actulizarAlbumEspecifico,eliminarAlbum} from "../controller/albumController.js"

const router = Router()

router.post('/album', crearDatosAlbum); 
router.get('/album', buscarAlbum); 
router.put('/album', actulizarAlbumEspecifico); 
router.delete('/album', eliminarAlbum); 


export default router;