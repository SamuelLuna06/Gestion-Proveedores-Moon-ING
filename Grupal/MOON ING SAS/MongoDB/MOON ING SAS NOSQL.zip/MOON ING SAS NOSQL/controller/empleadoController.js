import { empleadoModel } from "../model/empleadoModel.js";

export const registrarEmpleado = async (peticion, respuesta) => {
    try {
        let data = peticion.body
        await empleadoModel.create(data)
        let empleadoes = await empleadoModel.find()
        respuesta.status(200).render(send(empleadoes))
    } catch (error) {
        console.log(error);
    }
}

export const actualizarEmpleado = async (peticion, respuesta) => {
    try {
        let nombre = await empleadoModel.updateOne({
            idempleado: 2 /*...*/
        }, { $set: { correoempleado: "tecnitorrex@gmail.com" } });
        respuesta.status(200).render(send(nombre))
    }
    catch (error) {
        console.log(error);
    }
}

export const eliminarEmpleado = async (peticion, respuesta) => {
    try {
        let nombre = await empleadoModel.deleteOne({
            idempleado: 2 /*...*/
        });
        respuesta.status(200).render(send(nombre))
    }
    catch (error) {
        console.log(error);
    }
}

export const consultarEmpleado = async (peticion, respuesta) => {
    try {
        let empleadoes = await empleadoModel.find()
        respuesta.status(200).render("index", { empleadoes })
    } catch (error) {
        console.log(error);
    }
}

export const getEmpleadosPorEstado = async (peticion, respuesta) => {
    try {
        const { estado } = peticion.query; // Estado de la consulta
        const empleados = await empleadoModel.find({ estadoEmpleado: estado === 'true' });
        respuesta.status(200).send(empleados);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener empleados por estado' });
    }
};

export const getEmpleadosOrdenados = async (peticion, respuesta) => {
    try {
        const { campo, orden } = peticion.query; // Campo y orden de la consulta
        const sortOrder = orden === 'asc' ? 1 : -1;
        const sortObj = {};
        sortObj[campo] = sortOrder;
        const empleados = await empleadoModel.find().sort(sortObj);
        respuesta.status(200).send(empleados);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener empleados ordenados' });
    }
};

export const getEmpleadoPorId = async (peticion, respuesta) => {
    try {
        const { id } = peticion.params; // ID del empleado
        const empleado = await empleadoModel.findOne({ _id: id });
        respuesta.status(200).send(empleado);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener el empleado por ID' });
    }
};