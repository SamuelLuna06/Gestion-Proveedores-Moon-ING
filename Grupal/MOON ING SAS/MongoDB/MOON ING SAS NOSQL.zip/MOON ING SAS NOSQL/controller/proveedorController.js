import { proveedorModel } from "../model/proveedorModel.js";

export const registrarProveedor = async (peticion, respuesta) => {
    try {
        let data = peticion.body
        await proveedorModel.create(data)
        let proveedores = await proveedorModel.find()
        respuesta.status(200).render(send(proveedores))
    } catch (error) {
        console.log(error);
    }
}

export const actualizarProveedor = async (peticion, respuesta) => {
    try {
        const { id } = peticion.params; // ID del proveedor
        const data = peticion.body; // Datos para actualizar
        await proveedorModel.updateOne({ _id: id }, { $set: data });
        const proveedorActualizado = await proveedorModel.findOne({ _id: id });
        respuesta.status(200).send(proveedorActualizado);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al actualizar el proveedor' });
    }
};

export const eliminarProveedor = async (peticion, respuesta) => {
    try {
        let nombre = await proveedorModel.deleteOne({
            idProveedor: 2 /*...*/
        });
        respuesta.status(200).render(send(nombre))
    }
    catch (error) {
        console.log(error);
    }
}

export const consultarProveedor = async (peticion, respuesta) => {
    try {
        let proveedores = await proveedorModel.find()
        respuesta.status(200).render("index", { proveedores })
    } catch (error) {
        console.log(error);
    }
}

export const getProveedoresPorUbicacion = async (peticion, respuesta) => {
    try {
        const { ubicacion } = peticion.query; // Obtener ubicación de la consulta
        const proveedores = await proveedorModel.find({ ubicacion });
        respuesta.status(200).send(proveedores);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener proveedores por ubicación' });
    }
};

export const getProveedoresOrdenados = async (peticion, respuesta) => {
    try {
        const { campo, orden } = peticion.query; // Campo y orden desde la consulta
        const sortOrder = orden === 'asc' ? 1 : -1;
        const sortObj = {};
        sortObj[campo] = sortOrder;
        const proveedores = await proveedorModel.find().sort(sortObj);
        respuesta.status(200).send(proveedores);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener proveedores ordenados' });
    }
};

export const getProveedorPorId = async (peticion, respuesta) => {
    try {
        const { id } = peticion.params; // ID del proveedor
        const proveedor = await proveedorModel.findOne({ _id: id });
        respuesta.status(200).send(proveedor);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener el proveedor por ID' });
    }
};