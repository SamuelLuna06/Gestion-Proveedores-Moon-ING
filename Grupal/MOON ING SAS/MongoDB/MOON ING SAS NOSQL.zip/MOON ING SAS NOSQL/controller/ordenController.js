import { ordenModel } from "../model/ordenModel.js";

export const registrarOrden = async (peticion, respuesta) => {
    try {
        let data = peticion.body;
        await ordenModel.create(data);
        let orden = await ordenModel.find();
        respuesta.status(200).json(orden);
    } catch (error) {
        console.log(error);
        respuesta.status(500).json({ error: 'Error al registrar la orden' });
    }
}

export const actualizarOrden = async (peticion, respuesta) => {
    try {
        let { idOrden, productos } = peticion.body;
        let ordenActualizada = await ordenModel.updateOne(
            { idoorden: idOrden },
            { $set: { productos: productos } }
        );
        respuesta.status(200).json(ordenActualizada);
    } catch (error) {
        console.log(error);
        respuesta.status(500).json({ error: 'Error al actualizar la orden' });
    }
}

export const eliminarOrden = async (peticion, respuesta) => {
    try {
        let { idOrden } = peticion.body;
        let ordenEliminada = await ordenModel.deleteOne({ idoorden: idOrden });
        respuesta.status(200).json(ordenEliminada);
    } catch (error) {
        console.log(error);
        respuesta.status(500).json({ error: 'Error al eliminar la orden' });
    }
}

export const actualizarFechaOrden = async (peticion, respuesta) => {
    try {
        const { id } = peticion.params; // ID de la orden
        const { fecha } = peticion.body; // Fecha desde el cuerpo de la petición
        await ordenModel.updateOne({ _id: id }, { $set: { fechaOrden: new Date(fecha) } });
        const ordenActualizada = await ordenModel.findOne({ _id: id });
        respuesta.status(200).send(ordenActualizada);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al actualizar la fecha de la orden' });
    }
};

export const getOrdenesOrdenadas = async (peticion, respuesta) => {
    try {
        const { campo, orden } = peticion.query; // Campo y orden desde la consulta
        const sortOrder = orden === 'asc' ? 1 : -1;
        const sortObj = {};
        sortObj[campo] = sortOrder;
        const ordenes = await ordenModel.find().sort(sortObj);
        respuesta.status(200).send(ordenes);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener órdenes ordenadas' });
    }
};

export const getOrdenesPorRangoDeFechas = async (peticion, respuesta) => {
    try {
        const { fechaInicio, fechaFin } = peticion.query; // Fechas desde la consulta
        const ordenes = await ordenModel.find({
            fechaOrden: { $gte: new Date(fechaInicio), $lte: new Date(fechaFin) }
        });
        respuesta.status(200).send(ordenes);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener órdenes por rango de fechas' });
    }
};

export const getOrdenPorId = async (peticion, respuesta) => {
    try {
        const { id } = peticion.params; // ID de la orden
        const orden = await ordenModel.findOne({ _id: id });
        respuesta.status(200).send(orden);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener la orden por ID' });
    }
};