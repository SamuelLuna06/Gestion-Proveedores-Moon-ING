import { productoModel } from "../model/productoModel.js";

export const registrarProducto = async (peticion, respuesta) => {
    try {
        let data = peticion.body
        await productoModel.create(data)
        let producto = await productoModel.find()
        respuesta.status(200).render(send(producto))
    } catch (error) {
        console.log(error);
    }
}

export const actualizarProducto = async (peticion, respuesta) => {
    try {
        const { id } = peticion.params; // ID del producto desde los parámetros de la URL
        const data = peticion.body; // Datos para actualizar
        await productoModel.updateOne({ _id: id }, { $set: data });
        const productoActualizado = await productoModel.findOne({ _id: id });
        respuesta.status(200).send(productoActualizado);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al actualizar el producto' });
    }
};

export const eliminarProducto = async (peticion, respuesta) => {
    try {
        let nombre = await productoModel.deleteOne({
            idproducto: 2 /*...*/
        });
        respuesta.status(200).render(send(nombre))
    }
    catch (error) {
        console.log(error);
    }
}

export const consultarProducto = async (peticion, respuesta) => {
    try {
        let producto = await productoModel.find()
        rpuesta.status(200).render("index", { producto })
    } catch (error) {
        console.log(error);
    }
}

export const getProductosOrdenadosPorPrecio = async (peticion, respuesta) => {
    try {
        const { orden } = peticion.query; // Obtener orden (asc o desc) de la consulta
        const sortOrder = orden === 'asc' ? 1 : -1;
        const productos = await productoModel.find().sort({ precio: sortOrder });
        respuesta.status(200).send(productos);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener productos ordenados por precio' });
    }
};

export const getProductosOrdenadosPorNombre = async (peticion, respuesta) => {
    try {
        const { orden } = peticion.query; // Obtener orden (asc o desc) de la consulta
        const sortOrder = orden === 'asc' ? 1 : -1;
        const productos = await productoModel.find().sort({ nomProducto: sortOrder });
        respuesta.status(200).send(productos);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener productos ordenados por nombre' });
    }
};

export const getProductoPorId = async (peticion, respuesta) => {
    try {
        const { id } = peticion.params; // ID del producto desde los parámetros de la URL
        const producto = await productoModel.findOne({ _id: id });
        respuesta.status(200).send(producto);
    } catch (error) {
        console.log(error);
        respuesta.status(500).send({ error: 'Error al obtener el producto por ID' });
    }
};