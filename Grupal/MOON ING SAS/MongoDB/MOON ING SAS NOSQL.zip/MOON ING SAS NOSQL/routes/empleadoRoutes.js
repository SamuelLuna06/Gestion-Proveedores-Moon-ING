import express from 'express';
import { registrarEmpleado, actualizarEmpleado, eliminarEmpleado } from '../controller/empleadoController.js';

const router = express.Router();

router.post('/Empleado', registrarEmpleado);

router.put('/Empleado', actualizarEmpleado);

router.delete('/Empleado', eliminarEmpleado);

export default router;