import express from 'express';
import { registrarOrden, actualizarOrden, eliminarOrden } from '../controller/ordenController.js';

const router = express.Router();

router.post('/Orden', registrarOrden);

router.put('/Orden', actualizarOrden);

router.delete('/Orden', eliminarOrden);

export default router;