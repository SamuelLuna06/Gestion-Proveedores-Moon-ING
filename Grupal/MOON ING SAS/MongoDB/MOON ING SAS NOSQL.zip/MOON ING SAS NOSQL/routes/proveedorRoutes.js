import express from 'express';
import { registrarProveedor, actualizarProveedor, eliminarProveedor } from '../controller/proveedorController.js';

const router = express.Router();

router.post('/Proveedor', registrarProveedor);

router.put('/Proveedor', actualizarProveedor);

router.delete('/Proveedor', eliminarProveedor);

export default router;