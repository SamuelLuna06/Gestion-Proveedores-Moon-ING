import express from 'express';
import { registrarProducto, actualizarProducto, eliminarProducto } from '../controller/productoController.js';

const router = express.Router();

router.post('/Producto', registrarProducto);

router.put('/Producto', actualizarProducto);

router.delete('/Producto', eliminarProducto);

export default router;