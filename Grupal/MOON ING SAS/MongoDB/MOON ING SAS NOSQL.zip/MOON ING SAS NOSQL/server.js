import dotenv from 'dotenv'
dotenv.config();
import express, {json} from 'express'
import { __dirname } from "./util/__dirname.js"
import { connectDatabase } from "./config/database.js"
import empleadoRoutes from './routes/empleadoRoutes.js'
import proveedorRoutes from './routes/proveedorRoutes.js'
import productoRoutes from './routes/productoRoutes.js'
import ordenRoutes from './routes/ordenRoutes.js'

// Conexión a la BD
connectDatabase()
    .then(() => {
        console.log('Database connection successful');
    })
    .catch((error) => {
        console.error('Database connection failed:', error);
        process.exit(1);
    });

// Configurar servidor
const server = express()
const Port = process.env.PORT

server.use(express.json()); // Middleware para parsear JSON
server.use(express.urlencoded({ extended: true }));
server.use(express.static('public'));

// Configurar rutas de acceso
server.use('/empleado', empleadoRoutes)
server.use('/proveedor', proveedorRoutes)
server.use('/producto', productoRoutes)
server.use('/orden', ordenRoutes)

server.listen(Port, () => console.log(`Server runnin on port ${Port}`))