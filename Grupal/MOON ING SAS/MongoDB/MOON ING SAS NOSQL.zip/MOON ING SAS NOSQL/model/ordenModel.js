import mongoose, { Schema } from "mongoose";

const ordenSchema = new Schema({
    fechaOrden: Date,
    idEmpleado: String, /*DUDA*/
    productosOrden: [{
        idProducto: String,
        cantidadProducto: Number,
        precioProducto: Number
    }]
})

export const ordenModel = new mongoose.model('Orden', ordenSchema)