import mongoose, { Schema } from "mongoose";

const proveedorSchema = new Schema({
    nombreProveedor: String,
    ubicacionProveedor: String,
    contactoProveedor: String,
    correoProveedor: String,
    direccionProveedor: String
})

export const proveedorModel = new mongoose.model('Proveedor', proveedorSchema)