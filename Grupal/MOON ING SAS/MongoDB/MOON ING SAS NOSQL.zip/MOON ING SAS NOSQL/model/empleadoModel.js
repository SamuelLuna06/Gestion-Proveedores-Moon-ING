import mongoose, { Schema } from "mongoose";

const empleadoSchema = new Schema({
    nombreEmpleado: String,
    ccEmpleado: String,
    estadoEmpleado: Boolean
})

export const empleadoModel = new mongoose.model('Empleado', empleadoSchema)