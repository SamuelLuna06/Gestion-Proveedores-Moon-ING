import mongoose, { Schema } from "mongoose";

const productoSchema = new Schema({
    nomProducto: String,
    precio: Number
})

export const productoModel = new mongoose.model('producto', productoSchema)